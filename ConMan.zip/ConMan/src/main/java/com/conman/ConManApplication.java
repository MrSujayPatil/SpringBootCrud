package com.conman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConManApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConManApplication.class, args);
	}

}
